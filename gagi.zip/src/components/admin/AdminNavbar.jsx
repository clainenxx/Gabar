import { useEffect, useState } from "react";
import BrandLogo from "../BrandLogo.jsx";

// Navbar floating glassmorphism untuk /admin (Modul 13). Struktur & gaya
// sengaja dibuat konsisten dengan Navbar.jsx publik (pill melayang,
// backdrop-blur, berubah warna sedikit saat discroll, tombol hamburger
// yang membuka dropdown menyatu di bawah pill saat layar sempit).
//
// Beda dari Navbar publik: isi menunya bukan link scroll section, tapi
// daftar TAB panel admin (diminta owner 2026-09-15: "navbar di admin page
// samain kaya di main public page, ada garis hamburger buat buka navbar").
// Karena itu komponen ini menerima `tabs`/`activeTab`/`onTabChange` dari
// AdminPage — state tab tetap satu sumber kebenaran di AdminPage, navbar
// cuma menampilkan & mengirim balik pilihan user.
export default function AdminNavbar({
  profile,
  onLogout,
  tabs = [],
  activeTab,
  onTabChange,
  logoUrl,
}) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 8);
    }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const displayName = profile?.full_name || profile?.email || "Admin";

  function handleTabClick(key) {
    setMenuOpen(false);
    if (onTabChange) onTabChange(key);
  }

  return (
    <div className="fixed inset-x-0 top-3 sm:top-4 z-40 px-3 sm:px-6">
      <header
        className={`mx-auto max-w-5xl rounded-2xl border transition-colors duration-300 ${
          scrolled ? "bg-[#0b2447]/70 border-white/25" : "bg-white/10 border-white/20"
        } backdrop-blur-xl shadow-lg shadow-black/10`}
      >
        <div className="flex h-14 sm:h-16 items-center justify-between px-3 sm:px-5 gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <BrandLogo logoUrl={logoUrl} />
            <span className="min-w-0">
              <span className="block text-base sm:text-lg font-bold leading-none text-white">
                GABAR Admin
              </span>
              <span className="hidden sm:block text-[11px] leading-none text-white/70 mt-0.5 truncate">
                Gabin Ice Bar — panel kelola toko
              </span>
            </span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <span className="hidden sm:block text-sm text-white/85 truncate max-w-[10rem] md:max-w-xs">
              {displayName}
            </span>
            <button
              type="button"
              onClick={onLogout}
              className="flex items-center gap-1.5 rounded-xl bg-white/10 border border-white/30 px-3 py-2 text-xs sm:text-sm text-white hover:bg-white/20 transition-colors shrink-0"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{ height: 16, width: 16 }}
              >
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <polyline points="16 17 21 12 16 7" />
                <line x1="21" y1="12" x2="9" y2="12" />
              </svg>
              <span className="hidden xs:inline sm:inline">Logout</span>
            </button>

            {/* Hamburger: cuma muncul di layar sempit, persis pola Navbar
                publik — di >=md daftar tab sudah tampil sebagai sidebar
                di AdminPage, jadi menu ini akan mubazir di sana. */}
            <button
              type="button"
              onClick={() => setMenuOpen((v) => !v)}
              aria-label="Buka menu"
              aria-expanded={menuOpen}
              className="md:hidden flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 border border-white/25 text-white shrink-0 transition-transform duration-200 active:scale-90"
            >
              {menuOpen ? (
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" style={{ height: 18, width: 18 }}>
                  <path d="M18 6 6 18M6 6l12 12" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" style={{ height: 18, width: 18 }}>
                  <path d="M3 6h18M3 12h18M3 18h18" />
                </svg>
              )}
            </button>
          </div>
        </div>

        {menuOpen && (
          <nav className="animate-navbar-dropdown md:hidden flex flex-col gap-1 px-3 pb-3">
            {/* Nama admin yang login: di layar sempit tidak muat di baris
                atas, jadi ditampilkan di sini supaya tetap kelihatan. */}
            <span className="sm:hidden px-3 pt-1 pb-2 text-xs text-white/60 truncate">
              Login sebagai {displayName}
            </span>
            {tabs.map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => handleTabClick(tab.key)}
                className={`text-left rounded-lg px-3 py-2 text-sm transition-colors ${
                  activeTab === tab.key
                    ? "bg-white text-[#0b2447] font-medium"
                    : "text-white/85 hover:bg-white/10 hover:text-white"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        )}
      </header>
    </div>
  );
}
